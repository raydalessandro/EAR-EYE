import { useState, useRef, useCallback, useEffect } from 'react';
import * as deeplab from '@tensorflow-models/deeplab';
import * as tf from '@tensorflow/tfjs';
import { EARVector, EARState, KHistoryPoint, EAR_CONFIG, EAR_COLORS, CLASS_TO_EAR } from '../types/ear';
import { analyzeSegmentation, calculateK, getStatus, getDominant, smoothEAR } from '../utils/earCalculations';

interface UseSegmentationReturn {
  isModelLoaded: boolean;
  isLoading: boolean;
  loadError: string | null;
  earState: EARState;
  segmentationCanvas: React.RefObject<HTMLCanvasElement | null>;
  loadModel: () => Promise<void>;
  startAnalysis: (video: HTMLVideoElement) => void;
  stopAnalysis: () => void;
  fps: number;
}

const initialEAR: EARVector = { delta: 0.33, relation: 0.34, process: 0.33 };

const initialState: EARState = {
  current: initialEAR,
  previous: initialEAR,
  k: 0,
  kHistory: [],
  transitionCount: 0,
  status: 'stable',
  dominant: 'relation',
};

export function useSegmentation(): UseSegmentationReturn {
  const modelRef = useRef<deeplab.SemanticSegmentation | null>(null);
  const animationRef = useRef<number | null>(null);
  const lastTimeRef = useRef<number>(Date.now());
  const frameCountRef = useRef<number>(0);
  
  const segmentationCanvas = useRef<HTMLCanvasElement>(null);
  
  const [isModelLoaded, setIsModelLoaded] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [earState, setEarState] = useState<EARState>(initialState);
  const [fps, setFps] = useState(0);

  const loadModel = useCallback(async () => {
    try {
      setIsLoading(true);
      setLoadError(null);
      
      // Inizializza TensorFlow.js
      await tf.ready();
      
      // Carica modello DeepLab
      const model = await deeplab.load({
        base: 'pascal',
        quantizationBytes: 2, // Più leggero per mobile
      });
      
      modelRef.current = model;
      setIsModelLoaded(true);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Errore caricamento modello';
      setLoadError(message);
      console.error('Model loading error:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const processFrame = useCallback(async (video: HTMLVideoElement) => {
    if (!modelRef.current || !segmentationCanvas.current) return;
    
    try {
      // Esegui segmentazione
      const segmentation = await modelRef.current.segment(video);
      
      // Analizza distribuzione EAR
      const rawEAR = analyzeSegmentation(segmentation.segmentationMap);
      
      setEarState(prev => {
        // Smooth values
        const smoothed = smoothEAR(prev.current, rawEAR, EAR_CONFIG.SMOOTHING);
        
        // Calcola K
        const k = calculateK(prev.current, smoothed);
        
        // Aggiorna storia K
        const now = Date.now();
        const cutoff = now - EAR_CONFIG.TIMELINE_DURATION * 1000;
        const newHistory: KHistoryPoint[] = [
          ...prev.kHistory.filter(h => h.time > cutoff),
          { time: now, k, ear: smoothed }
        ];
        
        // Conta transizioni
        const isTransition = k > EAR_CONFIG.K_CRIT;
        const wasTransition = prev.k > EAR_CONFIG.K_CRIT;
        const newTransitionCount = isTransition && !wasTransition 
          ? prev.transitionCount + 1 
          : prev.transitionCount;
        
        // Vibrazione su transizione
        if (isTransition && !wasTransition && navigator.vibrate) {
          navigator.vibrate([100, 50, 100]);
        }
        
        return {
          current: smoothed,
          previous: prev.current,
          k,
          kHistory: newHistory,
          transitionCount: newTransitionCount,
          status: getStatus(k),
          dominant: getDominant(smoothed),
        };
      });
      
      // Visualizza segmentazione
      renderSegmentation(segmentation, segmentationCanvas.current);
      
      // Calcola FPS
      frameCountRef.current++;
      const now = Date.now();
      if (now - lastTimeRef.current > 1000) {
        setFps(frameCountRef.current);
        frameCountRef.current = 0;
        lastTimeRef.current = now;
      }
      
    } catch (err) {
      console.error('Frame processing error:', err);
    }
  }, []);

  const renderSegmentation = (
    segmentation: { segmentationMap: Uint8Array | Uint8ClampedArray; width: number; height: number },
    canvas: HTMLCanvasElement
  ) => {
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    const { width, height, segmentationMap } = segmentation;
    
    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
    }
    
    const imageData = ctx.createImageData(width, height);
    
    for (let i = 0; i < segmentationMap.length; i++) {
      const classId = segmentationMap[i];
      const earType = CLASS_TO_EAR[classId] || 'relation';
      const color = EAR_COLORS[earType];
      
      const idx = i * 4;
      imageData.data[idx] = color.r;
      imageData.data[idx + 1] = color.g;
      imageData.data[idx + 2] = color.b;
      imageData.data[idx + 3] = classId === 0 ? 30 : 100;
    }
    
    ctx.putImageData(imageData, 0, 0);
  };

  const analysisLoop = useCallback((video: HTMLVideoElement) => {
    const loop = async () => {
      await processFrame(video);
      animationRef.current = window.setTimeout(() => {
        requestAnimationFrame(() => loop());
      }, EAR_CONFIG.UPDATE_INTERVAL);
    };
    loop();
  }, [processFrame]);

  const startAnalysis = useCallback((video: HTMLVideoElement) => {
    if (animationRef.current) {
      clearTimeout(animationRef.current);
    }
    analysisLoop(video);
  }, [analysisLoop]);

  const stopAnalysis = useCallback(() => {
    if (animationRef.current) {
      clearTimeout(animationRef.current);
      animationRef.current = null;
    }
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopAnalysis();
    };
  }, [stopAnalysis]);

  return {
    isModelLoaded,
    isLoading,
    loadError,
    earState,
    segmentationCanvas,
    loadModel,
    startAnalysis,
    stopAnalysis,
    fps,
  };
}
