import { EARVector, CLASS_TO_EAR, EAR_CONFIG } from '../types/ear';

/**
 * Analizza la segmentazione e calcola distribuzione EAR
 */
export function analyzeSegmentation(segmentationMap: Uint8Array | Uint8ClampedArray): EARVector {
  const counts = { delta: 0, relation: 0, process: 0 };
  
  for (let i = 0; i < segmentationMap.length; i++) {
    const classId = segmentationMap[i];
    const earType = CLASS_TO_EAR[classId] || 'relation';
    counts[earType]++;
  }
  
  const total = segmentationMap.length;
  return {
    delta: counts.delta / total,
    relation: counts.relation / total,
    process: counts.process / total,
  };
}

/**
 * Calcola K (magnitudine transizione) tra due stati EAR
 */
export function calculateK(prev: EARVector, curr: EARVector): number {
  const dDelta = curr.delta - prev.delta;
  const dRelation = curr.relation - prev.relation;
  const dProcess = curr.process - prev.process;
  return Math.sqrt(dDelta * dDelta + dRelation * dRelation + dProcess * dProcess);
}

/**
 * Determina lo stato basato su K
 */
export function getStatus(k: number): 'stable' | 'variation' | 'transition' {
  if (k > EAR_CONFIG.K_CRIT) return 'transition';
  if (k > EAR_CONFIG.K_VARIATION) return 'variation';
  return 'stable';
}

/**
 * Determina l'attributo dominante
 */
export function getDominant(ear: EARVector): 'delta' | 'relation' | 'process' {
  const max = Math.max(ear.delta, ear.relation, ear.process);
  if (max === ear.delta) return 'delta';
  if (max === ear.relation) return 'relation';
  return 'process';
}

/**
 * Linear interpolation per smoothing
 */
export function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

/**
 * Smooth EAR vector
 */
export function smoothEAR(current: EARVector, target: EARVector, factor: number): EARVector {
  return {
    delta: lerp(current.delta, target.delta, factor),
    relation: lerp(current.relation, target.relation, factor),
    process: lerp(current.process, target.process, factor),
  };
}

/**
 * Formatta percentuale
 */
export function formatPercent(value: number): string {
  return `${Math.round(value * 100)}%`;
}

/**
 * Formatta K value
 */
export function formatK(k: number): string {
  return k.toFixed(3);
}
