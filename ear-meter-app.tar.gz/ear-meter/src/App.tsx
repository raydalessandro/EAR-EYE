import React, { useState, useCallback, useEffect } from 'react';
import { useCamera } from './hooks/useCamera';
import { useSegmentation } from './hooks/useSegmentation';
import { EARMeter, Timeline, StateCard, StartScreen } from './components';
import { EAR_CONFIG } from './types/ear';
import { formatK } from './utils/earCalculations';
import './App.css';

type AppState = 'start' | 'loading' | 'running';

const SYMBOL_MAP: Record<string, string> = {
  delta: 'Δ',
  relation: '⇄',
  process: '⟳',
};

function App() {
  const [appState, setAppState] = useState<AppState>('start');
  const [loadingMessage, setLoadingMessage] = useState('');
  const [showAlert, setShowAlert] = useState(false);
  
  const { videoRef, isActive: cameraActive, error: cameraError, startCamera } = useCamera();
  const { 
    isModelLoaded, 
    loadError,
    earState, 
    segmentationCanvas,
    loadModel,
    startAnalysis,
    fps
  } = useSegmentation();

  // Gestisce l'avvio
  const handleStart = useCallback(async () => {
    setAppState('loading');
    
    try {
      setLoadingMessage('Caricamento AI...');
      await loadModel();
      
      setLoadingMessage('Accesso camera...');
      await startCamera();
      
    } catch (err) {
      console.error('Start error:', err);
    }
  }, [loadModel, startCamera]);

  // Quando camera e modello sono pronti, avvia analisi
  useEffect(() => {
    if (cameraActive && isModelLoaded && videoRef.current) {
      setAppState('running');
      startAnalysis(videoRef.current);
    }
  }, [cameraActive, isModelLoaded, videoRef, startAnalysis]);

  // Flash su transizione
  useEffect(() => {
    if (earState.status === 'transition') {
      setShowAlert(true);
      const timer = setTimeout(() => setShowAlert(false), 300);
      return () => clearTimeout(timer);
    }
  }, [earState.transitionCount, earState.status]);

  const error = cameraError || loadError;

  if (appState !== 'running') {
    return (
      <StartScreen
        onStart={handleStart}
        isLoading={appState === 'loading'}
        loadingMessage={loadingMessage}
        error={error}
      />
    );
  }

  return (
    <div className="app">
      {/* Alert flash */}
      <div className={`alert-flash ${showAlert ? 'alert-flash--active' : ''}`} />
      
      {/* Header */}
      <header className="header">
        <div className="header__logo">
          EAR <span>Meter</span>
        </div>
        <div className="header__status">
          <div className={`status-dot ${cameraActive ? 'status-dot--active' : ''}`} />
          <span>Attivo</span>
        </div>
      </header>
      
      {/* Video container */}
      <div className="video-container">
        <video 
          ref={videoRef} 
          className="video-container__video"
          autoPlay 
          playsInline 
          muted 
        />
        <canvas 
          ref={segmentationCanvas}
          className="video-container__overlay"
        />
        <div className="video-container__info">
          <div className="fps-counter">{fps} fps</div>
          <div className={`k-display ${earState.status === 'transition' ? 'k-display--alert' : ''}`}>
            <span className="k-display__label">K</span>
            <span className="k-display__value">{formatK(earState.k)}</span>
            <span className="k-display__crit">/ {EAR_CONFIG.K_CRIT}</span>
          </div>
        </div>
      </div>
      
      {/* Meters */}
      <div className="meters-section">
        <EARMeter 
          type="delta"
          value={earState.current.delta}
          symbol="Δ"
          label="distinzione"
        />
        <EARMeter 
          type="relation"
          value={earState.current.relation}
          symbol="⇄"
          label="relazione"
        />
        <EARMeter 
          type="process"
          value={earState.current.process}
          symbol="⟳"
          label="processo"
        />
      </div>
      
      {/* State cards */}
      <div className="state-section">
        <StateCard 
          title="Stato"
          value={earState.status === 'stable' ? 'STABILE' : earState.status === 'variation' ? 'VARIAZIONE' : 'TRANSIZIONE'}
          variant={earState.status}
        />
        <StateCard 
          title="Dominante"
          value={SYMBOL_MAP[earState.dominant]}
          variant={earState.dominant}
        />
        <StateCard 
          title="Transizioni"
          value={String(earState.transitionCount)}
          variant="default"
        />
      </div>
      
      {/* Timeline */}
      <Timeline history={earState.kHistory} />
    </div>
  );
}

export default App;
