import React from 'react';
import './StartScreen.css';

interface StartScreenProps {
  onStart: () => void;
  isLoading: boolean;
  loadingMessage: string;
  error: string | null;
}

export const StartScreen: React.FC<StartScreenProps> = ({ 
  onStart, 
  isLoading, 
  loadingMessage,
  error 
}) => {
  return (
    <div className="start-screen">
      <h1 className="start-screen__title">EAR Meter</h1>
      <p className="start-screen__subtitle">Analisi ontologica in tempo reale</p>
      
      <div className="start-screen__explanation">
        <div className="ear-item">
          <div className="ear-item__symbol ear-item__symbol--delta">Δ</div>
          <div className="ear-item__desc">
            <strong>Distinzione</strong>
            <span>Confini, strutture, separazioni</span>
          </div>
        </div>
        
        <div className="ear-item">
          <div className="ear-item__symbol ear-item__symbol--relation">⇄</div>
          <div className="ear-item__desc">
            <strong>Relazione</strong>
            <span>Connessioni, superfici, mediazioni</span>
          </div>
        </div>
        
        <div className="ear-item">
          <div className="ear-item__symbol ear-item__symbol--process">⟳</div>
          <div className="ear-item__desc">
            <strong>Processo</strong>
            <span>Movimento, agenti, trasformazioni</span>
          </div>
        </div>
      </div>
      
      {error && (
        <div className="start-screen__error">
          {error}
        </div>
      )}
      
      {!isLoading ? (
        <button className="start-screen__button" onClick={onStart}>
          Avvia Camera
        </button>
      ) : (
        <div className="start-screen__loading">
          <div className="start-screen__spinner" />
          <span>{loadingMessage}</span>
        </div>
      )}
    </div>
  );
};
