import React from 'react';
import './StateCard.css';

interface StateCardProps {
  title: string;
  value: string;
  variant?: 'stable' | 'variation' | 'transition' | 'delta' | 'relation' | 'process' | 'default';
}

export const StateCard: React.FC<StateCardProps> = ({ title, value, variant = 'default' }) => {
  return (
    <div className="state-card">
      <h3 className="state-card__title">{title}</h3>
      <div className={`state-card__value state-card__value--${variant}`}>
        {value}
      </div>
    </div>
  );
};
