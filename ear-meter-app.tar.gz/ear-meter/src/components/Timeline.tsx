import React, { useRef, useEffect } from 'react';
import { KHistoryPoint, EAR_CONFIG } from '../types/ear';
import './Timeline.css';

interface TimelineProps {
  history: KHistoryPoint[];
}

export const Timeline: React.FC<TimelineProps> = ({ history }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Resize canvas per retina
    const rect = canvas.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);
    
    const width = rect.width;
    const height = rect.height;
    
    // Clear
    ctx.fillStyle = 'rgba(255, 255, 255, 0.02)';
    ctx.fillRect(0, 0, width, height);
    
    if (history.length < 2) return;
    
    const now = Date.now();
    const duration = EAR_CONFIG.TIMELINE_DURATION * 1000;
    const maxK = 0.5;
    
    // Disegna linea K_crit
    const critY = height - (EAR_CONFIG.K_CRIT / maxK) * height;
    ctx.strokeStyle = 'rgba(245, 158, 11, 0.5)';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.moveTo(0, critY);
    ctx.lineTo(width, critY);
    ctx.stroke();
    ctx.setLineDash([]);
    
    // Disegna curva K
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.7)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    
    let started = false;
    for (const point of history) {
      const x = ((point.time - (now - duration)) / duration) * width;
      const y = height - Math.min(point.k / maxK, 1) * height;
      
      if (x < 0) continue;
      
      if (!started) {
        ctx.moveTo(x, y);
        started = true;
      } else {
        ctx.lineTo(x, y);
      }
    }
    ctx.stroke();
    
    // Punti sopra soglia
    ctx.fillStyle = 'rgba(239, 68, 68, 0.9)';
    for (const point of history) {
      if (point.k > EAR_CONFIG.K_CRIT) {
        const x = ((point.time - (now - duration)) / duration) * width;
        if (x < 0) continue;
        const y = height - Math.min(point.k / maxK, 1) * height;
        ctx.beginPath();
        ctx.arc(x, y, 4, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  }, [history]);

  return (
    <div className="timeline">
      <h3 className="timeline__title">Timeline K (ultimi 30s)</h3>
      <div className="timeline__container">
        <canvas ref={canvasRef} className="timeline__canvas" />
      </div>
    </div>
  );
};
