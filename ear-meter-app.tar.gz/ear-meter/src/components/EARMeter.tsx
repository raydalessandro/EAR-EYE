import React from 'react';
import { EAR_COLORS } from '../types/ear';
import { formatPercent } from '../utils/earCalculations';
import './EARMeter.css';

interface EARMeterProps {
  type: 'delta' | 'relation' | 'process';
  value: number;
  label: string;
  symbol: string;
}

export const EARMeter: React.FC<EARMeterProps> = ({ type, value, label, symbol }) => {
  const color = EAR_COLORS[type].hex;
  
  return (
    <div className="ear-meter">
      <div className="ear-meter__symbol" style={{ color }}>
        {symbol}
      </div>
      <div className="ear-meter__bar-container">
        <div 
          className={`ear-meter__bar ear-meter__bar--${type}`}
          style={{ width: `${value * 100}%` }}
        />
      </div>
      <div className="ear-meter__value">
        {formatPercent(value)}
      </div>
      <div className="ear-meter__label">
        {label}
      </div>
    </div>
  );
};
