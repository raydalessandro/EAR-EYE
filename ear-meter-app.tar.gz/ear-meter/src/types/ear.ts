// EAR Ontology Types

export interface EARVector {
  delta: number;    // Δ - Distinzione (confini, strutture)
  relation: number; // ⇄ - Relazione (connessioni, superfici)
  process: number;  // ⟳ - Processo (movimento, agenti)
}

export interface EARState {
  current: EARVector;
  previous: EARVector;
  k: number;           // Magnitudine transizione
  kHistory: KHistoryPoint[];
  transitionCount: number;
  status: 'stable' | 'variation' | 'transition';
  dominant: 'delta' | 'relation' | 'process';
}

export interface KHistoryPoint {
  time: number;
  k: number;
  ear: EARVector;
}

export interface SegmentationResult {
  segmentationMap: Uint8Array;
  width: number;
  height: number;
}

// Configurazione
export const EAR_CONFIG = {
  K_CRIT: 0.35,
  K_VARIATION: 0.175,
  UPDATE_INTERVAL: 250,
  TIMELINE_DURATION: 30,
  SMOOTHING: 0.3,
} as const;

// Mappatura classi DeepLab Pascal VOC → EAR
// 0: background, 1: aeroplane, 2: bicycle, 3: bird, 4: boat,
// 5: bottle, 6: bus, 7: car, 8: cat, 9: chair,
// 10: cow, 11: diningtable, 12: dog, 13: horse, 14: motorbike,
// 15: person, 16: pottedplant, 17: sheep, 18: sofa, 19: train, 20: tvmonitor

export const CLASS_TO_EAR: Record<number, keyof EARVector> = {
  0: 'relation',    // background → ⇄
  1: 'process',     // aeroplane → ⟳
  2: 'process',     // bicycle → ⟳
  3: 'process',     // bird → ⟳
  4: 'process',     // boat → ⟳
  5: 'delta',       // bottle → Δ
  6: 'process',     // bus → ⟳
  7: 'process',     // car → ⟳
  8: 'process',     // cat → ⟳
  9: 'delta',       // chair → Δ
  10: 'process',    // cow → ⟳
  11: 'delta',      // diningtable → Δ
  12: 'process',    // dog → ⟳
  13: 'process',    // horse → ⟳
  14: 'process',    // motorbike → ⟳
  15: 'process',    // person → ⟳
  16: 'delta',      // pottedplant → Δ
  17: 'process',    // sheep → ⟳
  18: 'delta',      // sofa → Δ
  19: 'process',    // train → ⟳
  20: 'delta',      // tvmonitor → Δ
};

// Colori EAR per visualizzazione
export const EAR_COLORS = {
  delta: { r: 59, g: 130, b: 246, hex: '#3b82f6' },
  relation: { r: 16, g: 185, b: 129, hex: '#10b981' },
  process: { r: 239, g: 68, b: 68, hex: '#ef4444' },
} as const;
