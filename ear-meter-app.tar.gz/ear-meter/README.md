# EAR Meter

**Analisi ontologica in tempo reale** basata sul framework EAR (Emergent Adaptive Resonance).

## Cosa fa

Analizza il feed della camera e decompone la scena in tre attributi fondamentali:

- **Δ (Delta)** - Distinzione: confini, strutture, oggetti statici
- **⇄ (Relazione)** - Connessioni, superfici, mediazioni  
- **⟳ (Processo)** - Movimento, agenti, trasformazioni

## Come funziona

1. La camera cattura frame video
2. Un modello AI (DeepLab) segmenta la scena in classi semantiche
3. Le classi vengono mappate ai tre attributi EAR (Δ, ⇄, ⟳)
4. Viene calcolata la magnitudine di transizione **K** tra frame
5. Quando K supera la soglia critica (0.35), viene segnalato un cambio di contesto

## Tecnologie

- React + TypeScript
- TensorFlow.js
- DeepLab (segmentazione semantica)
- CSS moderno con CSS Variables

## Sviluppo

```bash
npm install
npm start
```

## Deploy

Configurato per Vercel - push su main per deploy automatico.

## Framework EAR

Basato su EAR NANO KERNEL v1.0 - un'ontologia minimale per AI che descrive la realtà attraverso tre attributi inseparabili (Δ, ⇄, ⟳) e le transizioni tra stati.

---

Made with EAR 🔬
